#include <mmu.h>
#include <pmap.h>
#include <print.h>

#undef NDEBUG

void test_list_insert_at() {
	struct Page_list test_list;
	LIST_INIT(&test_list);

	struct Page *pages = (struct Page *)alloc(5 * sizeof(struct Page), PAGE_SIZE, 1);

	LIST_INSERT_AT(Page, &test_list, &pages[0], pp_link, 0);
	LIST_INSERT_AT(Page, &test_list, &pages[2], pp_link, 1);
	LIST_INSERT_AT(Page, &test_list, &pages[1], pp_link, 1);
	LIST_INSERT_AT(Page, &test_list, &pages[3], pp_link, 0);
	LIST_INSERT_AT(Page, &test_list, &pages[4], pp_link, 4);

	struct Page *answer[] = {&pages[3], &pages[0], &pages[1], &pages[2], &pages[4]};

	struct Page *p = LIST_FIRST(&test_list);
	int j = 0;

	while (p != NULL) {
		assert(p == answer[j++]);
		p = LIST_NEXT(p, pp_link);
	}
	assert(j == 5);

	printk("test succeeded!\n");
}

void mips_init(u_int argc, char **argv, char **penv, u_int ram_low_size) {
	mips_detect_memory(ram_low_size);
	mips_vm_init();
	page_init();
	test_list_insert_at();
	halt();
}
